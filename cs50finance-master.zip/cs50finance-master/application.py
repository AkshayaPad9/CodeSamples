from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import mkdtemp
import time
import os
from helpers import *
import psycopg2

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# custom filter
app.jinja_env.filters["usd"] = usd

# configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# configure CS50 Library to use SQLite database
db = SQL(os.environ.get("DATABASE_URL") or "sqlite:///finance.db")

@app.route("/")
@login_required
def index():
    rows=db.execute("SELECT * FROM stocks WHERE user_id=:user", user=session["user_id"])
    index={}
    index["symbol"]=[]
    index["name"]=[]
    index["share"]=[]
    index["price1"]=[]
    index["tcost"]=[]
    rows1=db.execute("SELECT * FROM users WHERE id=:user", user=session["user_id"])
    totalMoney=float(rows1[0]["cash"])
    total=float(rows1[0]["cash"])
    print("total1" + str(total))
    if len(rows)!=0:
        for row in rows:
            price2=lookup(row['symbol'])
            index["symbol"].append(price2["symbol"])
            index["share"].append(int(row["number"]))
            index["price1"].append(float(price2["price"]))
            index["name"].append(price2["name"])
            index["tcost"].append(int(row["number"])*float(price2["price"]))
            total=total+int(row["number"])*float(price2["price"])
    print(total)
    leng=len(rows)
    return render_template("index.html", index=index, leng=leng,totalMoney=totalMoney, total=total)


@app.route("/history")
@login_required
def history():
    rows=db.execute("SELECT * FROM history WHERE id=:user", user=session["user_id"])
    history={}
    history["symbol"]=[]
    history["share"]=[]
    history["price1"]=[]
    history["datetime"]=[]
    if len(rows)!=0:
        for row in rows:
            history["symbol"].append(row["stock"])
            history["share"].append(row["stocknum"])
            price2=lookup(row['stock'])
            history["price1"].append(usd(price2["price"]))
            history["datetime"].append(row["datetime"])

    leng=len(rows)
    return render_template("history.html", history=history, leng=leng)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # forget any user_id
    session.clear()

    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 1 or not pwd_context.verify(request.form.get("password"), rows[0]["hash"]):
            return apology("invalid username and/or password")

        # remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out."""

    # forget any user_id
    session.clear()

    # redirect user to login form
    return redirect(url_for("login"))
    
@app.route("/forgotpassword", methods=["GET", "POST"])
def forgotpassword():
    if request.method=="POST":
        user=request.form.get("username")
        Hash=pwd_context.hash(request.form.get("new_password"))
        db.execute("UPDATE users SET hash=:new WHERE username=:u", new=Hash, u=user)
        return redirect(url_for("login"))
    else:
        return render_template("forgotpassword.html")

@app.route("/deposit", methods=["GET", "POST"])
@login_required
def deposit():
    if request.method=="POST":
        amount=request.form.get("amount")
        if not amount:
            return apology("Input money")
        rows=db.execute("SELECT * FROM users WHERE id=:user", user=session["user_id"])
        currentCash=rows[0]["cash"]
        newCash=currentCash+float(amount)
        db.execute("UPDATE users SET cash=:newc WHERE id=:u", newc=newCash, u=session["user_id"])
        return redirect(url_for("index"))
    else:
        return render_template("deposit.html")

@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        if not request.form.get("stock"):
            return apology("must provide stock name")
        stock=request.form.get("stock")
        if not lookup(stock):
            return apology("must be a valid stock symbol")
        quote=lookup(stock)
        s=quote["symbol"]
        c=quote["price"]
        return render_template("quotedisplay.html", symb=s,pric=c)

    else:
        return render_template("quote.html")
        

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    if request.method == "POST":
        if not request.form.get("stockn"):
            return apology("must provide stock name")
        if not request.form.get("nshare"):
            return apology("must provide number of stocks")
        sell1=lookup(request.form.get("stockn"))
        share=request.form.get("nshare")
        rows1=db.execute("SELECT * FROM stocks WHERE user_id=:id AND symbol=:sym", id=session["user_id"], sym=request.form.get("stockn"))
        if (int(share)>int(rows1[0]["number"])):
            return apology("invalid action")
        rows=db.execute("SELECT * FROM users WHERE (id=:id)", id=session["user_id"])
        get=float(sell1["price"])
        newnum=rows1[0]["number"]-int(request.form.get("nshare"))
        if (newnum==0):
            db.execute("DELETE FROM stocks WHERE user_id=:user AND symbol=:sym", user=session["user_id"], sym=request.form.get("stockn"))
        else:
            db.execute("UPDATE stocks SET number=:nu", nu=newnum)
        new=float(rows[0]["cash"])+float(sell1["price"])*int(share)
        print(rows[0]["cash"])
        print(float(sell1["price"]))
        print("I am" + str(new))
        db.execute("UPDATE users SET cash = :ne", ne=new)
        stocknum=-int(share)
        db.execute("INSERT INTO history (id, stock, stocknum, datetime) VALUES (:id,:stock,:stocknum, :datetime)", id=session["user_id"], stock=request.form.get("stockn"), stocknum=stocknum, datetime=time.strftime("%H:%M:%S %m/%d/%Y"))
        return redirect(url_for("index"))
    else:
        return render_template("sell.html")
        
@app.route("/selldisplay", methods=["GET", "POST"])
def selldisplay():
    sellsh=request.form.get("nshare")
    rows=db.execute("SELECT * FROM users WHERE id=:userid", userid=session["user_id"])
    rows2=db.execute("SELECT * FROM stocks WHERE user_id=:userid", userid=session["user_id"])
    c=lookup(rows2[0]["symbol"])
    n=float(c["price"])
    s=int(rows2[0]["number"])
    m=n*s
    return render_template("selldisplay.html", cas=m)
    
@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    if request.method == "POST":
        if not request.form.get("nstock"):
            return apology("must provide stock name")
        if not request.form.get("sharen"):
            return apology("must provide number of stocks")
        buy1=lookup(request.form.get("nstock"))
        share=request.form.get("sharen")
        rows=db.execute("SELECT * FROM users WHERE id=:user_id", user_id=session["user_id"])
        get=float(buy1["price"])
        if(float(rows[0]["cash"])<get):
            return apology("1: You do not have enough money to buy the stock")
        if(float(rows[0]["cash"])<int(share)*float(buy1["price"])):
            return apology("You do not have enough money to buy the stock")
        else:
            new=float(rows[0]["cash"])-float(buy1["price"])*int(share)
            db.execute("UPDATE users SET cash = :ne", ne=new)
        rowbuy=db.execute("SELECT * from stocks WHERE (user_id=:id AND symbol=:sym)", id=session["user_id"], sym=request.form.get("nstock"))
        if (len(rowbuy)==0):
            db.execute("INSERT INTO stocks (user_id, symbol, number) VALUES (:id,:symbol,:number)", id=session["user_id"], symbol=request.form.get("nstock"), number=share)
        else:
            currentnum = rowbuy[0]["number"]
            num1=currentnum+int(request.form.get("sharen"))
            db.execute("UPDATE stocks SET number=:num WHERE user_id=:id AND symbol=:sym", num=num1, id=session["user_id"], sym=request.form.get("nstock"))
        db.execute("INSERT INTO history (id, stock, stocknum, datetime) VALUES (:id,:stock,:stocknum, :datetime)", id=session["user_id"], stock=request.form.get("nstock"), stocknum=share, datetime=time.strftime("%H:%M:%S %d/%m/%Y"))
        return redirect(url_for("index"))
    else:
        return render_template("buy.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")
        
        elif not request.form.get("password2"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 0:
            return apology("this username already exists")
        
        if request.form.get("password")!=request.form.get("password2"):
            return apology("the passwords do not match")

        Hash=pwd_context.hash(request.form.get('password'))
        
        db.execute("INSERT INTO users (username,hash) values (:username, :password)", username=request.form.get("username"), password=Hash)

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")

if __name__=="__main__":
    port = int(os.environ.get("PORT",8080))
    app.run(host="0.0.0.0", port=port)

